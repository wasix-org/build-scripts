
"""
Module to expose more detailed version info for the installed `numpy`
"""
version = "2.4.0.dev0+git20250724.a4906a7"
__version__ = version
full_version = version

git_revision = "a4906a744754260e2ad166c14ca1b9ff8926cb6c"
release = 'dev' not in version and '+' not in version
short_version = version.split("+")[0]
