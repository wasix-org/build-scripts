__all__ = ["PyZbarError"]


class PyZbarError(Exception):
    pass
